package com.tencent.rtmp.demo.videojoiner.widget.swipemenu;

public interface SwipeSwitch extends Openable, Closeable {

}
